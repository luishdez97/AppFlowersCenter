package com.example.fc;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class Ver_Precios extends AppCompatActivity {

    EditText codigo;
    TextView producto,precio;
    Button leer,consultar;
    String TipoProd;

    private ZXingScannerView vistascanner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_precios);
    }

    public void Escanear(View view)
    {
        vistascanner=new ZXingScannerView(this);
        vistascanner.setResultHandler(new zxingscaner());
        setContentView(vistascanner);
        vistascanner.startCamera();
    }

    class  zxingscaner implements ZXingScannerView.ResultHandler
    {
        @Override
        public void handleResult(com.google.zxing.Result result) {
            String dato=result.getText();
            setContentView(R.layout.activity_ver_precios);
            vistascanner.stopCamera();
            codigo=(EditText)findViewById(R.id.codprod);
            codigo.setText(dato);
            BuscarPrecio2();
        }
    }

    public Connection ConexionBD()
    {
        Connection conexion =null;
        try
        {
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            conexion= DriverManager.getConnection("jdbc:jtds:sqlserver://190.106.3.18:1433;databaseName=FLOWERSCENTERBD;user=app;password=$app2019;");

        }
        catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
        return conexion;
    }

    public void BuscarPrecio (View view)
    {
        String sql;
        try
        {
            codigo=(EditText)findViewById(R.id.codprod);


            PreparedStatement pst =ConexionBD().prepareStatement("SELECT * FROM PRODUCTOS WHERE COD_PROD=? ");
            pst.setString(1,codigo.getText().toString());

            ResultSet rs = pst.executeQuery();
            if (rs.next())
            {
                producto=(TextView) findViewById(R.id.producto);
                producto.setText(rs.getString("DESCRIPCION"));
                TipoProd=rs.getString("TIPO_PROD");
                //return true;
            }
            else
            {
                Toast.makeText(getApplicationContext(),"EL CODIGO DE ESE PRODUCTO NO EXISTE "  ,Toast.LENGTH_SHORT).show();
                //return false;
            }
            if (TipoProd.equals("Flores"))
            {
                pst =ConexionBD().prepareStatement("SELECT * FROM TIPO_PRECIOS WHERE UNIDAD=1 AND COD_PROD=? ");

            }   else
            {
                pst =ConexionBD().prepareStatement("SELECT * FROM TIPO_PRECIOS WHERE UNIDAD=3 AND COD_PROD=? ");
            }


            pst.setString(1,codigo.getText().toString());

            rs = pst.executeQuery();
            if (rs.next())
            {
                precio=(TextView) findViewById(R.id.precio);
                precio.setText("C$ " + rs.getString("PREC_PART"));
                //return true;
            }
            else
            {
                Toast.makeText(getApplicationContext(),"EL CODIGO DE ESE PRODUCTO NO EXISTE "  ,Toast.LENGTH_SHORT).show();
                //return false;
            }

            rs.close();



        }
        catch (SQLException e) {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
            // return false;
        }
    }

    public void BuscarPrecio2 ()
    {
        String sql;
        try
        {
            codigo=(EditText)findViewById(R.id.codprod);
            PreparedStatement pst =ConexionBD().prepareStatement("SELECT * FROM PRODUCTOS WHERE COD_PROD=? ");
            pst.setString(1,codigo.getText().toString());

            ResultSet rs = pst.executeQuery();
            if (rs.next())
            {
                producto=(TextView) findViewById(R.id.producto);
                producto.setText(rs.getString("DESCRIPCION"));
                TipoProd=rs.getString("TIPO_PROD");
                //return true;
            }
            else
            {
                Toast.makeText(getApplicationContext(),"EL CODIGO DE ESE PRODUCTO NO EXISTE "  ,Toast.LENGTH_SHORT).show();
                //return false;
            }
            if (TipoProd.equals("Flores"))
            {
                pst =ConexionBD().prepareStatement("SELECT * FROM TIPO_PRECIOS WHERE UNIDAD=1 AND COD_PROD=? ");

            }   else
            {
                pst =ConexionBD().prepareStatement("SELECT * FROM TIPO_PRECIOS WHERE UNIDAD=3 AND COD_PROD=? ");
            }


            pst.setString(1,codigo.getText().toString());

            rs = pst.executeQuery();
            if (rs.next())
            {
                precio=(TextView) findViewById(R.id.precio);
                precio.setText("C$ " + rs.getString("PREC_PART"));
                //return true;
            }
            else
            {
                Toast.makeText(getApplicationContext(),"EL CODIGO DE ESE PRODUCTO NO EXISTE "  ,Toast.LENGTH_SHORT).show();
                //return false;
            }

            rs.close();



        }
        catch (SQLException e) {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
            // return false;
        }
    }

}
