package com.example.fc.ui.grab_pedidos;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class grab_pedidos_ViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public grab_pedidos_ViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Grabacion de pedidos");
    }

    public LiveData<String> getText() {
        return mText;
    }
}